'use strict';
/**
 * @ngdoc function
 * @name imageCrmApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the imageCrmApp
 */
angular.module('imageCrmApp')
  .controller('FormCtrl', ["$scope", function($scope) {
}]);