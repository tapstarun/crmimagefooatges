<?php

/**
 * Database config variables
 */
define("DB_HOST", "localhost"); //write your host
define("DB_USER", "root"); //write your db username
define("DB_PASSWORD", ""); //write your db password
define("DB_DATABASE", "image_footage"); //write your database name
?>
